"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export default function NewsletterPage() {
  const [email, setEmail] = useState("")
  const [preferences, setPreferences] = useState({
    newArrivals: false,
    promotions: false,
    charityUpdates: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement newsletter signup logic here
    console.log("Newsletter signup:", { email, preferences })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Subscribe to Our Newsletter</h1>
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Stay Updated with CeelyRose</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div>
              <Label>Preferences</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="newArrivals"
                    checked={preferences.newArrivals}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, newArrivals: checked as boolean }))
                    }
                  />
                  <Label htmlFor="newArrivals">New Arrivals</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="promotions"
                    checked={preferences.promotions}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, promotions: checked as boolean }))
                    }
                  />
                  <Label htmlFor="promotions">Promotions and Deals</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="charityUpdates"
                    checked={preferences.charityUpdates}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, charityUpdates: checked as boolean }))
                    }
                  />
                  <Label htmlFor="charityUpdates">Charity Updates</Label>
                </div>
              </div>
            </div>
            <Button type="submit" className="w-full">Subscribe</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

