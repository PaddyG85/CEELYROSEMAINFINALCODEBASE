"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { Checkbox } from "@/components/ui/checkbox"

const charityShops = [
  { id: 1, name: "BookLove Charity Shop", location: "London", cause: "Literacy", bookCount: 1500 },
  { id: 2, name: "ReadWell Charity", location: "Manchester", cause: "Education", bookCount: 1200 },
  { id: 3, name: "LiteracyFirst Charity", location: "Birmingham", cause: "Children's Education", bookCount: 1800 },
  { id: 4, name: "PageTurner Foundation", location: "Liverpool", cause: "Adult Learning", bookCount: 1000 },
  { id: 5, name: "WordsForGood Charity", location: "Edinburgh", cause: "Community Libraries", bookCount: 1300 },
]

export default function CharityShopsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [location, setLocation] = useState("")
  const [distance, setDistance] = useState([50])
  const [cause, setCause] = useState("")
  const [searchNationally, setSearchNationally] = useState(false);

  const filteredShops = charityShops.filter((shop) => {
    const matchesSearch = shop.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesLocation = location === "" || shop.location.toLowerCase().includes(location.toLowerCase())
    const matchesCause = cause === "" || shop.cause.toLowerCase().includes(cause.toLowerCase())
    return matchesSearch && matchesLocation && matchesCause
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Charity Shop Directory</h1>
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Find a Charity Shop</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <Label htmlFor="search">Search</Label>
              <Input
                id="search"
                placeholder="Search by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="Enter location..."
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="distance">Distance (miles)</Label>
              <Slider
                id="distance"
                min={1}
                max={100}
                step={1}
                value={distance}
                onValueChange={setDistance}
              />
              <div className="text-sm text-gray-500 mt-1">Within {distance} miles</div>
            </div>
            <div>
              <Label htmlFor="cause">Charity Cause</Label>
              <Input
                id="cause"
                placeholder="Enter cause..."
                value={cause}
                onChange={(e) => setCause(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="search-nationally"
                checked={searchNationally}
                onCheckedChange={(checked) => setSearchNationally(checked as boolean)}
              />
              <Label htmlFor="search-nationally">Search Nationally</Label>
            </div>
          </div>
        </CardContent>
      </Card>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredShops.map((shop) => (
          <Card key={shop.id}>
            <CardHeader>
              <CardTitle>{shop.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-2">Location: {shop.location}</p>
              <p className="mb-2">Cause: {shop.cause}</p>
              <p className="mb-4">Books available: {shop.bookCount}</p>
              <Button asChild>
                <Link href={`/charity-shops/${shop.id}`}>View Shop</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

