"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const categories = [
  "Fiction", "Non-Fiction", "Mystery", "Thriller", "Romance", "Science Fiction",
  "Fantasy", "Horror", "Biography", "Autobiography", "History", "Politics",
  "Philosophy", "Psychology", "Self-Help", "Business", "Economics", "Science",
  "Technology", "Art", "Music", "Travel", "Cooking", "Health", "Sports",
  "Children's", "Young Adult", "Poetry", "Drama", "Comics", "Graphic Novels"
]

export function BookListingForm() {
  const [book, setBook] = useState({
    title: "",
    author: "",
    isbn: "",
    price: "",
    category: "",
    condition: "",
    description: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setBook(prev => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setBook(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    // Implement book listing creation logic here
    console.log("Book listed", book)
  }

  const handleBulkUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Implement bulk upload logic here
      console.log("Bulk upload file:", file.name)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>List a Book</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Book Title</Label>
            <Input
              id="title"
              name="title"
              value={book.title}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="author">Author</Label>
            <Input
              id="author"
              name="author"
              value={book.author}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="isbn">ISBN</Label>
            <Input
              id="isbn"
              name="isbn"
              value={book.isbn}
              onChange={handleChange}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="price">Price (£)</Label>
            <Input
              id="price"
              name="price"
              type="number"
              step="0.01"
              value={book.price}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select name="category" value={book.category} onValueChange={handleSelectChange("category")}>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category.toLowerCase()}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="condition">Condition</Label>
            <Select name="condition" value={book.condition} onValueChange={handleSelectChange("condition")}>
              <SelectTrigger>
                <SelectValue placeholder="Select book condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="like-new">Like New</SelectItem>
                <SelectItem value="very-good">Very Good</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="acceptable">Acceptable</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={book.description}
              onChange={handleChange}
            />
          </div>
          <Button type="submit">List Book</Button>
        </form>
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-2">Bulk Upload</h3>
          <Input
            type="file"
            accept=".csv,.xlsx"
            onChange={handleBulkUpload}
          />
          <p className="text-sm text-gray-500 mt-2">
            Upload a CSV or Excel file with multiple book listings.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

