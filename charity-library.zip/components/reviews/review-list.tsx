import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Star } from 'lucide-react'

interface Review {
  id: string
  userName: string
  rating: number
  comment: string
  date: string
}

interface ReviewListProps {
  reviews: Review[]
}

export function ReviewList({ reviews }: ReviewListProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Customer Reviews</CardTitle>
      </CardHeader>
      <CardContent>
        {reviews.map((review) => (
          <div key={review.id} className="mb-4 pb-4 border-b last:border-b-0">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold">{review.userName}</span>
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-4 w-4 ${
                      star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-1">{review.comment}</p>
            <span className="text-xs text-gray-400">{review.date}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

