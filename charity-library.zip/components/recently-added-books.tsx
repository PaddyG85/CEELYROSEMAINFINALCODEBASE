"use client"

import { useState, useEffect } from "react"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
  addedAt: string
}

function getRelativeTimeString(date: Date): string {
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diffInSeconds < 60) {
    return `${diffInSeconds} seconds ago`
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60)
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600)
    return `${hours} hour${hours > 1 ? 's' : ''} ago`
  } else {
    const days = Math.floor(diffInSeconds / 86400)
    return `${days} day${days > 1 ? 's' : ''} ago`
  }
}

export function RecentlyAddedBooks() {
  const [recentBooks, setRecentBooks] = useState<Book[]>([])

  useEffect(() => {
    // In a real application, this would be an API call
    const fetchRecentBooks = async () => {
      // Simulating an API call with setTimeout
      setTimeout(() => {
        const now = new Date()
        setRecentBooks([
          {
            id: 1,
            title: "The Midnight Library",
            author: "Matt Haig",
            price: 8.99,
            categories: ["Fiction", "Contemporary"],
            image: "/placeholder.svg",
            charityShop: "BookLove Charity Shop",
            addedAt: new Date(now.getTime() - 23 * 60 * 1000).toISOString() // 23 minutes ago
          },
          {
            id: 2,
            title: "Atomic Habits",
            author: "James Clear",
            price: 10.99,
            categories: ["Non-Fiction", "Self-Help"],
            image: "/placeholder.svg",
            charityShop: "ReadWell Charity",
            addedAt: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString() // 2 hours ago
          },
          {
            id: 3,
            title: "The Thursday Murder Club",
            author: "Richard Osman",
            price: 7.99,
            categories: ["Fiction", "Mystery"],
            image: "/placeholder.svg",
            charityShop: "LiteracyFirst Charity",
            addedAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString() // 2 days ago
          },
          {
            id: 4,
            title: "Where the Crawdads Sing",
            author: "Delia Owens",
            price: 9.99,
            categories: ["Fiction", "Literary"],
            image: "/placeholder.svg",
            charityShop: "PageTurner Foundation",
            addedAt: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString() // 5 days ago
          }
        ])
      }, 1000)
    }

    fetchRecentBooks()
  }, [])

  return (
    <div className="mt-8">
      <h3 className="text-2xl font-bold text-teal-700 mb-4">Recently Added Books</h3>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {recentBooks.map((book) => (
          <div key={book.id} className="flex flex-col">
            <BookCard book={book} compact={true} />
            <p className="text-sm text-gray-600 mt-2">
              Added {getRelativeTimeString(new Date(book.addedAt))}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

