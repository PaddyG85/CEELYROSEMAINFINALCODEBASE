"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Order {
  id: string
  date: string
  total: number
  status: string
  items: { title: string; quantity: number; price: number }[]
}

export function OrderHistory() {
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "ORD-001",
      date: "2023-05-15",
      total: 32.97,
      status: "Delivered",
      items: [
        { title: "The Great Gatsby", quantity: 1, price: 9.99 },
        { title: "To Kill a Mockingbird", quantity: 2, price: 11.49 },
      ],
    },
    {
      id: "ORD-002",
      date: "2023-06-02",
      total: 24.99,
      status: "Processing",
      items: [
        { title: "1984", quantity: 1, price: 10.99 },
        { title: "Pride and Prejudice", quantity: 1, price: 8.99 },
        { title: "The Catcher in the Rye", quantity: 1, price: 5.01 },
      ],
    },
  ])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Order History</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order ID</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell>{order.id}</TableCell>
                <TableCell>{order.date}</TableCell>
                <TableCell>£{order.total.toFixed(2)}</TableCell>
                <TableCell>{order.status}</TableCell>
                <TableCell>
                  <Button variant="outline" size="sm">View Details</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

