"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

// Mock data for charity shops
const charityShops = [
  { id: 1, name: "BookLove Charity Shop", address: "123 High Street, London, UK" },
  { id: 2, name: "ReadWell Charity", address: "456 Main Road, Manchester, UK" },
  { id: 3, name: "LiteracyFirst Charity", address: "789 Book Lane, Birmingham, UK" },
]

export default function DonateBooks() {
  const [donationType, setDonationType] = useState("single")
  const [bookInfo, setBookInfo] = useState({
    title: "",
    author: "",
    condition: "",
    description: "",
  })
  const [bundleInfo, setBundleInfo] = useState({
    description: "",
    quantity: "",
  })
  const [selectedCharity, setSelectedCharity] = useState("")
  const [charityAddress, setCharityAddress] = useState("")
  const [deliveryMethod, setDeliveryMethod] = useState("collection")

  const handleBookInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setBookInfo(prev => ({ ...prev, [name]: value }))
  }

  const handleBundleInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setBundleInfo(prev => ({ ...prev, [name]: value }))
  }

  const handleConditionChange = (value: string) => {
    setBookInfo(prev => ({ ...prev, condition: value }))
  }

  const handleCharityChange = (value: string) => {
    setSelectedCharity(value)
    const selectedShop = charityShops.find(shop => shop.name === value)
    setCharityAddress(selectedShop ? selectedShop.address : "")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send this data to your backend
    console.log("Donation submitted:", {
      type: donationType,
      info: donationType === "single" ? bookInfo : bundleInfo,
      charity: selectedCharity,
      address: charityAddress,
      deliveryMethod,
    })
    // In a real application, you would send a notification to the charity shop here
    console.log(`Notification sent to ${selectedCharity}`)
    // Reset form after submission
    setBookInfo({ title: "", author: "", condition: "", description: "" })
    setBundleInfo({ description: "", quantity: "" })
    setSelectedCharity("")
    setCharityAddress("")
    setDeliveryMethod("collection")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Donate Books</h1>
      <Card>
        <CardHeader>
          <CardTitle>Book Donation Form</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={donationType} onValueChange={setDonationType}>
            <TabsList className="mb-4">
              <TabsTrigger value="single">Single</TabsTrigger>
              <TabsTrigger value="bundle">Bundle</TabsTrigger>
            </TabsList>
            <form onSubmit={handleSubmit} className="space-y-4">
              <TabsContent value="single">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700">Book Title</label>
                  <Input
                    id="title"
                    name="title"
                    value={bookInfo.title}
                    onChange={handleBookInfoChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="author" className="block text-sm font-medium text-gray-700">Author</label>
                  <Input
                    id="author"
                    name="author"
                    value={bookInfo.author}
                    onChange={handleBookInfoChange}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="condition" className="block text-sm font-medium text-gray-700">Condition</label>
                  <Select onValueChange={handleConditionChange} value={bookInfo.condition}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select book condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="like-new">Like New</SelectItem>
                      <SelectItem value="very-good">Very Good</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="acceptable">Acceptable</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
                  <Textarea
                    id="description"
                    name="description"
                    value={bookInfo.description}
                    onChange={handleBookInfoChange}
                    rows={4}
                  />
                </div>
              </TabsContent>
              <TabsContent value="bundle">
                <div>
                  <label htmlFor="bundleDescription" className="block text-sm font-medium text-gray-700">Bundle Description</label>
                  <Textarea
                    id="bundleDescription"
                    name="description"
                    value={bundleInfo.description}
                    onChange={handleBundleInfoChange}
                    rows={4}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">Approximate Number of Books</label>
                  <Input
                    id="quantity"
                    name="quantity"
                    type="number"
                    value={bundleInfo.quantity}
                    onChange={handleBundleInfoChange}
                    required
                  />
                </div>
              </TabsContent>
              <div>
                <label htmlFor="charity" className="block text-sm font-medium text-gray-700">Select Charity Shop</label>
                <Select onValueChange={handleCharityChange} value={selectedCharity}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a charity shop" />
                  </SelectTrigger>
                  <SelectContent>
                    {charityShops.map((shop) => (
                      <SelectItem key={shop.id} value={shop.name}>{shop.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {charityAddress && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">Charity Shop Address</label>
                  <p className="mt-1 text-sm text-gray-500">{charityAddress}</p>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Method</label>
                <RadioGroup value={deliveryMethod} onValueChange={setDeliveryMethod}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="collection" id="collection" />
                    <Label htmlFor="collection">Collection by Charity</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Label htmlFor="delivery">Delivery by Donor</Label>
                  </div>
                </RadioGroup>
              </div>
              <Button type="submit">Submit Donation</Button>
            </form>
          </Tabs>
        </CardContent>
      </Card>
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Why Donate?</h2>
        <p className="mb-4">
          Your book donations help support local charities and promote literacy in communities across the UK. 
          By donating your books, you're giving them a second life and helping others discover the joy of reading.
        </p>
        <Link href="/faq" className="text-teal-600 hover:text-teal-700 font-medium">
          Learn more about our donation process
        </Link>
      </div>
    </div>
  )
}

