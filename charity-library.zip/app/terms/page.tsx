import { Metadata } from 'next'

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "Read our Terms of Service to understand the rules and regulations governing the use of CeelyRose's services.",
}

export default function TermsOfServicePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      <div className="prose max-w-none">
        <h2>1. Acceptance of Terms</h2>
        <p>By accessing and using CeelyRose's services, you agree to be bound by these Terms of Service.</p>

        <h2>2. Description of Service</h2>
        <p>CeelyRose provides an online platform connecting users with charity shops for the purpose of buying and donating second-hand books.</p>

        <h2>3. User Obligations</h2>
        <p>Users agree to provide accurate information, maintain account security, and use the service in compliance with all applicable laws.</p>

        <h2>4. Intellectual Property</h2>
        <p>All content on CeelyRose, unless otherwise stated, is the property of CeelyRose and protected by copyright laws.</p>

        <h2>5. Limitation of Liability</h2>
        <p>CeelyRose is not liable for any indirect, incidental, or consequential damages arising from your use of our services.</p>

        <h2>6. Modifications to Service</h2>
        <p>CeelyRose reserves the right to modify or discontinue the service at any time without notice.</p>

        <h2>7. Governing Law</h2>
        <p>These terms are governed by the laws of the United Kingdom.</p>

        <h2>8. Contact Information</h2>
        <p>For any questions regarding these Terms of Service, please contact us at legal@ceelyrose.com.</p>
      </div>
    </div>
  )
}

