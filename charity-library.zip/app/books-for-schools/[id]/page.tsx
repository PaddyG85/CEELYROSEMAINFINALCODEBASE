import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { ShoppingCart, Heart } from 'lucide-react'

const bundles = [
  {
    id: 1,
    name: "Elementary Classics",
    books: [
      { title: "Charlotte's Web", condition: "Good" },
      { title: "The Giving Tree", condition: "Very Good" },
      { title: "Where the Wild Things Are", condition: "Like New" },
      // ... add more books
    ],
    price: 49.99,
    image: "/placeholder.svg",
    description: "A collection of timeless classics perfect for elementary school libraries or young readers.",
    charityShop: "BookLove Charity Shop"
  },
  // ... add other bundles
]

export default function BookBundlePage({ params }: { params: { id: string } }) {
  const bundle = bundles.find(b => b.id === parseInt(params.id))

  if (!bundle) {
    return <div>Bundle not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-primary mb-6">{bundle.name}</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <Image src={bundle.image} alt={bundle.name} width={600} height={400} className="rounded-lg" />
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Bundle Details</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">{bundle.description}</p>
            <p className="mb-4">Number of books: {bundle.books.length}</p>
            <p className="text-2xl font-bold mb-4">Price: £{bundle.price.toFixed(2)}</p>
            <div className="flex space-x-4 mb-4">
              <Button className="flex-1">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Add to Cart
              </Button>
              <Button variant="outline">
                <Heart className="mr-2 h-4 w-4" />
                Add to Wishlist
              </Button>
            </div>
            <Link href={`/charity-shops/1`} className="text-primary hover:underline">
              View {bundle.charityShop} Profile
            </Link>
          </CardContent>
        </Card>
      </div>
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Books in this Bundle</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5">
            {bundle.books.map((book, index) => (
              <li key={index} className="mb-2">
                {book.title} - Condition: {book.condition}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

