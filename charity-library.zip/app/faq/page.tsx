import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function FAQPage() {
  const faqs = [
    {
      question: "How does CeelyRose work?",
      answer: "CeelyRose is an online platform that connects readers with charity shops across the UK. You can browse and purchase second-hand books from various charity shops, all in one place. When you make a purchase, the book is shipped directly from the charity shop to you.",
    },
    {
      question: "How do I know the condition of the book I'm buying?",
      answer: "Each book listing includes a detailed description of the book's condition. We use a standardized rating system (New, Like New, Very Good, Good, Acceptable) to help you understand the book's state before purchasing.",
    },
    {
      question: "Can I return a book if I'm not satisfied?",
      answer: "Yes, we have a 14-day return policy. If you're not satisfied with your purchase, you can return the book for a full refund, minus shipping costs. Please note that the book must be in the same condition as when you received it.",
    },
    {
      question: "How much of my purchase goes to charity?",
      answer: "A significant portion of each sale goes directly to the charity shop. While the exact percentage can vary, typically 70-80% of the sale price goes to the charity, with the remainder covering our operational costs and shipping.",
    },
    {
      question: "Can I donate books through CeelyRose?",
      answer: "Yes, you can donate books through CeelyRose! We've implemented a book donation feature where you can list your books for donation. Charity shops can then request these books, and you'll be able to arrange delivery or pickup. This way, you can ensure your books go directly to charity shops that need them. Visit our 'Donate Books' page to get started.",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Frequently Asked Questions</h1>
      <Card>
        <CardHeader>
          <CardTitle>Common Questions About CeelyRose</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger>{faq.question}</AccordionTrigger>
                <AccordionContent>{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  )
}

