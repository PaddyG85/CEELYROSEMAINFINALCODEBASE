import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ReviewForm } from "@/components/reviews/review-form"
import { ReviewList } from "@/components/reviews/review-list"
import Image from "next/image"
import Link from "next/link"

// This would typically come from an API or database
const book = {
  id: 1,
  title: "To Kill a Mockingbird",
  author: "Harper Lee",
  price: 5.99,
  categories: ["Fiction", "Classic"],
  image: "/placeholder.svg",
  charityShop: "BookLove Charity Shop",
  description: "To Kill a Mockingbird is a novel by Harper Lee published in 1960. It was immediately successful, winning the Pulitzer Prize, and has become a classic of modern American literature.",
  condition: "Good",
  isbn: "9780446310789",
  reviews: [
    { id: 1, userName: "John Doe", rating: 5, comment: "A timeless classic that everyone should read.", date: "2023-05-15" },
    { id: 2, userName: "Jane Smith", rating: 4, comment: "Beautifully written and thought-provoking.", date: "2023-06-02" },
  ]
}

export default function BookDetailsPage({ params }: { params: { id: string } }) {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <Image
            src={book.image}
            alt={book.title}
            width={400}
            height={600}
            className="w-full object-cover rounded-lg shadow-md"
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold mb-2">{book.title}</h1>
          <p className="text-xl mb-4">by {book.author}</p>
          <p className="text-2xl font-bold mb-4">£{book.price.toFixed(2)}</p>
          <div className="mb-4">
            {book.categories.map((category) => (
              <span key={category} className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">
                {category}
              </span>
            ))}
          </div>
          <p className="mb-4">{book.description}</p>
          <Card className="mb-4">
            <CardContent className="pt-6">
              <p><strong>Condition:</strong> {book.condition}</p>
              <p><strong>ISBN:</strong> {book.isbn}</p>
              <p><strong>Sold by:</strong> {book.charityShop}</p>
            </CardContent>
          </Card>
          <div className="flex gap-4">
            <Button>Add to Cart</Button>
            <Button variant="outline">Add to Wishlist</Button>
          </div>
        </div>
      </div>
      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Customer Reviews</h2>
        <ReviewList reviews={book.reviews} />
        <div className="mt-6">
          <h3 className="text-xl font-bold mb-2">Write a Review</h3>
          <ReviewForm bookId={params.id} />
        </div>
      </div>
    </div>
  )
}

