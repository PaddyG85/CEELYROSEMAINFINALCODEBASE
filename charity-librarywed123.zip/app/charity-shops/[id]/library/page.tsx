"use client"

import { useState, useEffect } from "react"
import { BookCard } from "@/components/book-card"
import { Button } from "@/components/ui/button"
import { useInView } from "react-intersection-observer"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
  addedAt: string
}

export default function CharityShopLibrary({ params }: { params: { id: string } }) {
  const [books, setBooks] = useState<Book[]>([])
  const [loading, setLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [ref, inView] = useInView()

  const loadMoreBooks = async () => {
    if (loading || !hasMore) return
    setLoading(true)
    // In a real application, you would fetch books from an API
    // This is a mock implementation
    const newBooks = Array.from({ length: 12 }, (_, i) => ({
      id: books.length + i + 1,
      title: `Book ${books.length + i + 1}`,
      author: `Author ${books.length + i + 1}`,
      price: Math.floor(Math.random() * 20) + 5,
      categories: ["Fiction", "Non-Fiction"][Math.floor(Math.random() * 2)],
      image: "/placeholder.svg",
      charityShop: `Charity Shop ${params.id}`,
      addedAt: new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString()
    }))
    setBooks(prevBooks => [...prevBooks, ...newBooks])
    setLoading(false)
    if (books.length + newBooks.length >= 100) {
      setHasMore(false)
    }
  }

  useEffect(() => {
    loadMoreBooks()
  }, [])

  useEffect(() => {
    if (inView) {
      loadMoreBooks()
    }
  }, [inView])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Charity Shop Library</h1>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {books.map(book => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
      {hasMore && (
        <div ref={ref} className="flex justify-center mt-8">
          <Button onClick={loadMoreBooks} disabled={loading}>
            {loading ? "Loading..." : "Load More"}
          </Button>
        </div>
      )}
    </div>
  )
}

