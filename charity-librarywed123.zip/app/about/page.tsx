import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-primary">About CeelyRose</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Our Mission</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              CeelyRose is dedicated to supporting British charities by creating a platform where book lovers can purchase second-hand books from charity shops across the UK. Our mission is to promote literacy, support local charities, and encourage sustainable reading habits.
            </p>
            <p className="mb-4">
              By connecting readers with charity shops, we aim to:
            </p>
            <ul className="list-disc list-inside mb-4">
              <li>Increase funding for charitable causes</li>
              <li>Reduce waste by promoting the reuse of books</li>
              <li>Provide affordable access to a wide range of literature</li>
              <li>Support local communities and their charity shops</li>
            </ul>
          </CardContent>
        </Card>
        <div>
          <Image
            src="/placeholder.svg"
            alt="CeelyRose Team"
            width={600}
            height={400}
            className="rounded-lg shadow-md mb-4"
          />
          <Card>
            <CardHeader>
              <CardTitle>Our Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Since our inception, CeelyRose has:
              </p>
              <ul className="list-disc list-inside mb-4">
                <li>Facilitated the sale of over 100,000 second-hand books</li>
                <li>Partnered with 500+ charity shops across the UK</li>
                <li>Raised £1 million for various charitable causes</li>
                <li>Saved an estimated 500 tons of paper through book reuse</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

