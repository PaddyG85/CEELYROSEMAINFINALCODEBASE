import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import Link from "next/link"

export default function HelpCenterPage() {
  const faqs = [
    {
      question: "How do I place an order?",
      answer: "To place an order, simply browse our selection of books, add items to your cart, and proceed to checkout. Follow the prompts to enter your shipping and payment information."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept major credit cards (Visa, MasterCard, American Express) and PayPal."
    },
    {
      question: "How long will it take to receive my order?",
      answer: "Delivery times vary depending on your location and the charity shop's processing time. Generally, you can expect your order within 3-7 business days."
    },
    {
      question: "Can I return a book?",
      answer: "Yes, we offer a 14-day return policy. Please contact us if you need to return an item."
    },
    {
      question: "How can I donate books?",
      answer: "You can donate books through our 'Donate Books' page. Select a charity shop and follow the instructions to arrange for collection or drop-off."
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Help Center</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Contact Us</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">If you can't find the answer to your question, please don't hesitate to contact us:</p>
            <p className="mb-2"><strong>Phone:</strong> (+86) 132-8061-3915</p>
            <p className="mb-4"><strong>Email:</strong> CeelyRose@outlook.com</p>
            <p className="mb-4">Our customer service team is available Monday to Friday, 9am to 5pm GMT.</p>
            <Link href="/contact" className="text-primary hover:underline">
              Visit our Contact Page for more ways to reach us
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

