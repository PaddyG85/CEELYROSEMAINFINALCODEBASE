import { SearchBar } from "@/components/search/search-bar"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, BookOpen, Book } from 'lucide-react'
import { RecentlyAddedBooks } from "@/components/recently-added-books"
import { PersonalizedRecommendations } from "@/components/personalized-recommendations"

export default function Home() {
  return (
    <>
      <section className="bg-gradient-to-b from-secondary to-background py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary leading-tight">
                Elevate Your Reading,{" "}
                <span className="block text-accent">Support British Charities</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Join our distinguished community of book enthusiasts and make a soaring difference with every purchase.
              </p>
              <SearchBar />
            </div>
            <div className="relative aspect-square shimmer">
              <Image
                src="/placeholder.svg"
                alt="RAF-inspired charity shop books"
                fill
                className="object-cover rounded-lg shadow-lg"
                priority
              />
              {/* Icon removed */}
            </div>
          </div>
        </div>
      </section>

      <section className="py-4 md:py-16 bg-background">
        <div className="container mx-auto px-4">
          <RecentlyAddedBooks />
          <PersonalizedRecommendations />
        </div>
      </section>

      <section className="py-16 md:py-24 bg-secondary shimmer">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Explore Our Distinguished Collection
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Discover a carefully curated array of books from various genres and find your next literary mission.
          </p>
          <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/nationwide-library" className="inline-flex items-center">
              Browse the Nationwide Library
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Precision Collections for Schools
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Tactical selections for schools, book clubs, and avid readers. Enjoy strategic pricing on our meticulously curated book bundles.
          </p>
          <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/books-for-schools" className="inline-flex items-center">
              Explore Collections
              <Book className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-secondary shimmer">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Join Our Mission: Donate Your Books
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Have books that have completed their tour of duty? Deploy them through CeelyRose and support charity shops across the UK.
          </p>
          <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/donate-books" className="inline-flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              Donate Books
            </Link>
          </Button>
        </div>
      </section>
    </>
  )
}

