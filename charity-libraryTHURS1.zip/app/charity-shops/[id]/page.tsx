"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookCard } from "@/components/book-card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"
import Image from "next/image"
import { MessageCircle, Heart, ShoppingCart, Search } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// This would typically come from an API or database
const charityShop = {
  id: 1,
  name: "BookLove Charity Shop",
  description: "BookLove Charity Shop is dedicated to promoting literacy and supporting local community projects through the sale of second-hand books.",
  location: "123 High Street, London, UK",
  phoneNumber: "+44 20 1234 5678",
  image: "/placeholder.svg",
  books: [
    { id: 1, title: "To Kill a Mockingbird", author: "Harper Lee", price: 5.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop", addedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() },
    { id: 2, title: "1984", author: "George Orwell", price: 4.99, categories: ["Fiction", "Dystopian"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop", addedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString() },
    { id: 3, title: "Pride and Prejudice", author: "Jane Austen", price: 3.99, categories: ["Fiction", "Romance"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop", addedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() },
    { id: 4, title: "The Great Gatsby", author: "F. Scott Fitzgerald", price: 6.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop", addedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() },
  ]
}

const genres = [
  "Fiction", "Non-Fiction", "Mystery", "Science Fiction", "Romance", "Biography", "History", "Self-Help", "Children's"
]

function getRelativeTimeString(date: Date): string {
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diffInSeconds < 60) {
    return `${diffInSeconds} seconds ago`
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60)
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600)
    return `${hours} hour${hours > 1 ? 's' : ''} ago`
  } else {
    const days = Math.floor(diffInSeconds / 86400)
    return `${days} day${days > 1 ? 's' : ''} ago`
  }
}

export default function CharityShopPage({ params }: { params: { id: string } }) {
  const [showDonationOptions, setShowDonationOptions] = useState(false)
  const [donationAmount, setDonationAmount] = useState("")
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [showBookDonation, setShowBookDonation] = useState(false)
  const [bookDonationDescription, setBookDonationDescription] = useState("")
  const [bookDonationQuantity, setBookDonationQuantity] = useState("")
  const [donationMethod, setDonationMethod] = useState("collection")
  const [donationDate, setDonationDate] = useState<Date | undefined>(new Date())
  const [donationTime, setDonationTime] = useState("morning")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedGenre, setSelectedGenre] = useState("All")

  const handleDonation = () => {
    // Implement donation logic here
    console.log("Donation made:", { amount: donationAmount, isAnonymous })
    // Reset form and hide options
    setDonationAmount("")
    setIsAnonymous(false)
    setShowDonationOptions(false)
  }

  const handleBookDonation = () => {
    // Implement book donation logic here
    console.log("Book donation scheduled:", {
      description: bookDonationDescription,
      quantity: bookDonationQuantity,
      method: donationMethod,
      date: donationDate,
      time: donationTime
    })
    // Reset form and hide options
    setBookDonationDescription("")
    setBookDonationQuantity("")
    setDonationMethod("collection")
    setDonationDate(new Date())
    setDonationTime("morning")
    setShowBookDonation(false)
  }

  const filteredBooks = charityShop.books.filter(book => 
    (selectedGenre === "All" || book.categories.includes(selectedGenre)) &&
    (book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
     book.author.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">{charityShop.name}</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>About Us</CardTitle>
          </CardHeader>
          <CardContent>
            <Image
              src={charityShop.image}
              alt={charityShop.name}
              width={400}
              height={300}
              className="w-full object-cover rounded-lg mb-4"
            />
            <p className="mb-4">{charityShop.description}</p>
            <p className="mb-2"><strong>Location:</strong> {charityShop.location}</p>
            <p className="mb-4"><strong>Phone:</strong> {charityShop.phoneNumber}</p>
            <Button asChild className="w-full mb-2">
              <Link href={`/messaging?shop=${params.id}`}>
                <MessageCircle className="mr-2 h-4 w-4" /> Message Us
              </Link>
            </Button>
            <div className="space-y-4">
              <div>
                <Button 
                  className="w-full mb-2" 
                  onClick={() => setShowDonationOptions(!showDonationOptions)}
                >
                  Donate to {charityShop.name}
                </Button>
                {showDonationOptions && (
                  <div className="mt-4 space-y-4">
                    <Input
                      type="number"
                      placeholder="£0.00"
                      value={donationAmount}
                      onChange={(e) => {
                        const value = parseFloat(e.target.value);
                        setDonationAmount(isNaN(value) ? "" : value.toFixed(2));
                      }}
                      step="0.01"
                      min="0"
                    />
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="anonymous"
                        checked={isAnonymous}
                        onCheckedChange={() => setIsAnonymous(!isAnonymous)}
                      />
                      <Label htmlFor="anonymous">Make donation anonymous</Label>
                    </div>
                    <Button onClick={handleDonation}>Confirm Donation</Button>
                  </div>
                )}
              </div>
              <Button 
                className="w-full" 
                onClick={() => setShowBookDonation(!showBookDonation)}
              >
                Donate Books
              </Button>
            </div>
            {showBookDonation && (
              <div className="mt-4 space-y-4">
                <Textarea
                  placeholder="Describe the books you're donating"
                  value={bookDonationDescription}
                  onChange={(e) => setBookDonationDescription(e.target.value)}
                />
                <Input
                  type="number"
                  placeholder="Quantity of books"
                  value={bookDonationQuantity}
                  onChange={(e) => setBookDonationQuantity(e.target.value)}
                />
                <RadioGroup value={donationMethod} onValueChange={setDonationMethod}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="collection" id="collection" />
                    <Label htmlFor="collection">Collection</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dropoff" id="dropoff" />
                    <Label htmlFor="dropoff">Drop-off at shop</Label>
                  </div>
                </RadioGroup>
                <Calendar
                  mode="single"
                  selected={donationDate}
                  onSelect={setDonationDate}
                  className="rounded-md border"
                />
                <RadioGroup value={donationTime} onValueChange={setDonationTime}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="morning" id="morning" />
                    <Label htmlFor="morning">Morning</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="afternoon" id="afternoon" />
                    <Label htmlFor="afternoon">Afternoon</Label>
                  </div>
                </RadioGroup>
                <Button onClick={handleBookDonation}>Schedule Book Donation</Button>
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Our Library</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Input
                type="text"
                placeholder="Search books..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-2"
              />
              <div>
                <div className="mb-4 flex flex-wrap gap-2">
                  <Button 
                    variant={selectedGenre === "All" ? "default" : "outline"}
                    onClick={() => setSelectedGenre("All")}
                  >
                    All
                  </Button>
                  {genres.map((genre) => (
                    <Button
                      key={genre}
                      variant={selectedGenre === genre ? "default" : "outline"}
                      onClick={() => setSelectedGenre(genre)}
                    >
                      {genre}
                    </Button>
                  ))}
                </div>
                <div className="grid gap-4 grid-cols-2">
                  {filteredBooks.map((book) => (
                    <div key={book.id} className="relative">
                      <Link href={`/books/${book.id}`}>
                        <BookCard book={book} compact />
                      </Link>
                      <p className="text-sm text-gray-600 mt-1">
                        Added {getRelativeTimeString(new Date(book.addedAt))}
                      </p>
                      <div className="absolute top-2 right-2 flex space-x-2">
                        <Button size="icon" variant="ghost">
                          <Heart className="h-4 w-4" />
                        </Button>
                        <Button size="icon">
                          <ShoppingCart className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <Button asChild className="w-full">
              <Link href={`/charity-shops/${params.id}/library`}>
                View Full Library
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

