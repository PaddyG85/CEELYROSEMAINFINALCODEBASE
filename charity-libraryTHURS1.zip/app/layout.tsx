import type { Metadata } from "next"
import { Inter } from 'next/font/google'
import "./globals.css"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { CookieConsent } from "@/components/cookie-consent"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "CeelyRose - Support British Charities with Second-Hand Books",
    template: "%s | CeelyRose"
  },
  description: "CeelyRose connects book lovers with charity shops across the UK. Buy second-hand books and support great causes.",
  keywords: ["charity", "books", "second-hand", "UK", "reading", "donation"],
  authors: [{ name: "CeelyRose" }],
  openGraph: {
    type: "website",
    locale: "en_GB",
    url: "https://www.ceelyrose.com/",
    siteName: "CeelyRose",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "CeelyRose - Support British Charities with Second-Hand Books",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    site: "@ceelyrose",
    creator: "@ceelyrose",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen flex flex-col`}>
        <Navigation />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
        <CookieConsent />
      </body>
    </html>
  )
}

