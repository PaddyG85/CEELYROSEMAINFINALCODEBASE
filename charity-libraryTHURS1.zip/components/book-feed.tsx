"use client"

import { useEffect, useRef, useState } from "react"
import { BookCard } from "@/components/book-card"
import { useInView } from "react-intersection-observer"

// Mock data - replace with actual API call
const generateMockBooks = (start: number, end: number) => {
  return Array.from({ length: end - start }, (_, i) => ({
    id: start + i,
    title: `Book Title ${start + i}`,
    author: `Author ${start + i}`,
    price: Math.floor(Math.random() * 20) + 5,
    categories: ["Fiction", "Mystery", "Thriller"].sort(() => Math.random() - 0.5).slice(0, 2),
    image: `/placeholder.svg?text=Book${start + i}`,
    charityShop: `Charity Shop ${Math.floor(Math.random() * 5) + 1}`,
  }))
}

export function BookFeed() {
  const [books, setBooks] = useState(generateMockBooks(0, 20))
  const [loading, setLoading] = useState(false)
  const [ref, inView] = useInView()

  const loadMore = async () => {
    setLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setBooks(prev => [...prev, ...generateMockBooks(prev.length, prev.length + 20)])
    setLoading(false)
  }

  useEffect(() => {
    if (inView && !loading) {
      loadMore()
    }
  }, [inView])

  return (
    <div className="space-y-6">
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
        {books.map((book) => (
          <BookCard key={book.id} book={book} compact={true} />
        ))}
      </div>
      <div ref={ref} className="h-10 flex items-center justify-center">
        {loading && <div className="text-center text-gray-500">Loading more books...</div>}
      </div>
    </div>
  )
}

