"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

export function RecentlyViewed() {
  const [recentlyViewed, setRecentlyViewed] = useState<Book[]>([])

  useEffect(() => {
    // In a real application, this would be fetched from local storage or an API
    const fetchRecentlyViewed = () => {
      setRecentlyViewed([
        {
          id: 1,
          title: "Pride and Prejudice",
          author: "Jane Austen",
          price: 7.99,
          categories: ["Fiction", "Romance"],
          image: "/placeholder.svg",
          charityShop: "LiteracyFirst Charity"
        },
        {
          id: 2,
          title: "The Great Gatsby",
          author: "F. Scott Fitzgerald",
          price: 9.99,
          categories: ["Fiction", "Classic"],
          image: "/placeholder.svg",
          charityShop: "BookLove Charity Shop"
        },
        {
          id: 3,
          title: "Moby-Dick",
          author: "Herman Melville",
          price: 11.99,
          categories: ["Fiction", "Adventure"],
          image: "/placeholder.svg",
          charityShop: "ReadWell Charity"
        }
      ])
    }

    fetchRecentlyViewed()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recently Viewed</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recentlyViewed.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

