"use client"

import { useState, useEffect } from "react"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

export function PersonalizedRecommendations() {
  const [recommendations, setRecommendations] = useState<Book[]>([])

  useEffect(() => {
    // In a real app, this would be an API call based on user's history
    const fetchRecommendations = async () => {
      // Simulating API call
      setTimeout(() => {
        setRecommendations([
          { id: 1, title: "The Catcher in the Rye", author: "J.D. Salinger", price: 5.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "BookLove Charity" },
          { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", price: 4.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "ReadWell Charity" },
          { id: 3, title: "1984", author: "George Orwell", price: 6.99, categories: ["Fiction", "Dystopian"], image: "/placeholder.svg", charityShop: "LiteracyFirst Charity" },
          { id: 4, title: "Pride and Prejudice", author: "Jane Austen", price: 4.99, categories: ["Fiction", "Romance"], image: "/placeholder.svg", charityShop: "PageTurner Foundation" },
        ])
      }, 1000)
    }

    fetchRecommendations()
  }, [])

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold text-teal-700 mb-4">Recommended for You</h2>
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {recommendations.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  )
}

