"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

export function PersonalizedRecommendations() {
  const [recommendations, setRecommendations] = useState<Book[]>([])

  useEffect(() => {
    // In a real application, this would be an API call to get personalized recommendations
    const fetchRecommendations = async () => {
      // Simulating an API call with setTimeout
      setTimeout(() => {
        setRecommendations([
          {
            id: 1,
            title: "The Catcher in the Rye",
            author: "J.D. Salinger",
            price: 8.99,
            categories: ["Fiction", "Classic"],
            image: "/placeholder.svg",
            charityShop: "BookLove Charity Shop"
          },
          {
            id: 2,
            title: "To Kill a Mockingbird",
            author: "Harper Lee",
            price: 10.99,
            categories: ["Fiction", "Classic"],
            image: "/placeholder.svg",
            charityShop: "ReadWell Charity"
          },
          {
            id: 3,
            title: "1984",
            author: "George Orwell",
            price: 9.99,
            categories: ["Fiction", "Dystopian"],
            image: "/placeholder.svg",
            charityShop: "LiteracyFirst Charity"
          }
        ])
      }, 1000)
    }

    fetchRecommendations()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recommended for You</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recommendations.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

