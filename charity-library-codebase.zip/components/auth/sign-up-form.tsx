"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export function SignUpForm() {
  const [userType, setUserType] = useState("customer")

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    // Implement sign up logic here
    console.log("Sign up submitted")
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label>I am a:</Label>
        <RadioGroup value={userType} onValueChange={setUserType} className="flex gap-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="customer" id="customer" />
            <Label htmlFor="customer">Customer</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="charity" id="charity" />
            <Label htmlFor="charity">Charity Shop</Label>
          </div>
        </RadioGroup>
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input id="password" type="password" required />
      </div>
      {userType === "charity" && (
        <div className="space-y-2">
          <Label htmlFor="shopName">Charity Shop Name</Label>
          <Input id="shopName" type="text" required />
        </div>
      )}
      <Button type="submit" className="w-full">Sign Up</Button>
    </form>
  )
}

