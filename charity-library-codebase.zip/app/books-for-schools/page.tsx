import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const bundles = [
  { id: 1, name: "Elementary Classics", books: 10, price: 49.99 },
  { id: 2, name: "Middle School Mysteries", books: 15, price: 69.99 },
  { id: 3, name: "High School Literature", books: 20, price: 89.99 },
]

export default function BooksForSchools() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-teal-700 mb-6">Books for Schools</h1>
      <p className="text-lg mb-8">
        Bulk purchase options for schools, book clubs, and avid readers. Enjoy discounted prices on curated book bundles!
      </p>
      <div className="grid gap-6 md:grid-cols-3">
        {bundles.map((bundle) => (
          <Card key={bundle.id}>
            <CardHeader>
              <CardTitle>{bundle.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">{bundle.books} books</p>
              <p className="text-2xl font-bold mb-4">£{bundle.price.toFixed(2)}</p>
              <Button className="w-full">Add to Cart</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

