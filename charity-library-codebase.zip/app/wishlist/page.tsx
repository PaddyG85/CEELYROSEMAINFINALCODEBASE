"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

export default function WishlistPage() {
  const [wishlistItems, setWishlistItems] = useState<Book[]>([
    { id: 1, title: "1984", author: "George Orwell", price: 10.99, categories: ["Fiction", "Dystopian"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop" },
    { id: 2, title: "Pride and Prejudice", author: "Jane Austen", price: 8.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "ReadWell Charity" },
  ])

  const removeFromWishlist = (id: number) => {
    setWishlistItems(wishlistItems.filter(item => item.id !== id))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Your Wishlist</h1>
      <Card>
        <CardHeader>
          <CardTitle>Wishlist Items</CardTitle>
        </CardHeader>
        <CardContent>
          {wishlistItems.length === 0 ? (
            <p>Your wishlist is empty.</p>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {wishlistItems.map((book) => (
                <div key={book.id} className="relative">
                  <BookCard book={book} />
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={() => removeFromWishlist(book.id)}
                  >
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

