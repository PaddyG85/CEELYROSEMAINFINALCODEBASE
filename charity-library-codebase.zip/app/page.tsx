import { SearchBar } from "@/components/search/search-bar"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { ArrowRight, BookOpen } from 'lucide-react'
import { RecentlyAddedBooks } from "@/components/recently-added-books"
import { PersonalizedRecommendations } from "@/components/personalized-recommendations"

export default function Home() {
  return (
    <>
      <section className="bg-gradient-to-b from-teal-50 to-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-teal-700 leading-tight">
                Support British Charities,{" "}
                <span className="block">Shop with Purpose</span>
              </h1>
              <p className="text-lg text-gray-600 max-w-lg">
                Join our community of compassionate shoppers and make a difference with every purchase.
              </p>
              <SearchBar />
            </div>
            <div className="relative aspect-square">
              <Image
                src="/placeholder.svg"
                alt="Charity shop books"
                fill
                className="object-cover rounded-lg shadow-lg"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <RecentlyAddedBooks />
          <PersonalizedRecommendations />
        </div>
      </section>

      <section className="py-16 md:py-24 bg-teal-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-teal-700 mb-4">
            Explore Our Library
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Discover a vast collection of books from various categories and find your next favorite read.
          </p>
          <Button size="lg" asChild className="bg-teal-600 hover:bg-teal-700">
            <Link href="/library" className="inline-flex items-center">
              Visit Library
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-teal-700 mb-4">
            Books for Schools
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Bulk purchase options for schools, book clubs, and avid readers. Enjoy discounted prices on curated book bundles!
          </p>
          <Button size="lg" asChild className="bg-teal-600 hover:bg-teal-700">
            <Link href="/books-for-schools" className="inline-flex items-center">
              Explore Bundles
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-teal-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-teal-700 mb-4">
            Donate Your Books
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Have books you no longer need? Donate them through CeelyRose and support charity shops across the UK!
          </p>
          <Button size="lg" asChild className="bg-teal-600 hover:bg-teal-700">
            <Link href="/donate-books" className="inline-flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              Donate Books
            </Link>
          </Button>
        </div>
      </section>
    </>
  )
}

