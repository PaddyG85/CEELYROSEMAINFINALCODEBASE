"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SalesChart } from "@/components/dashboard/sales-chart"
import { BookListingForm } from "@/components/book-management/book-listing-form"
import { CommissionTracker } from "@/components/dashboard/commission-tracker"
import { CharityNotification } from "@/components/notifications/charity-notification"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Charity Shop Dashboard</h1>
        <CharityNotification />
      </div>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="books">Manage Books</TabsTrigger>
          <TabsTrigger value="commissions">Commissions</TabsTrigger>
          <TabsTrigger value="donations">Donations</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Sales Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <SalesChart />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="books">
          <BookListingForm />
        </TabsContent>
        <TabsContent value="commissions">
          <CommissionTracker />
        </TabsContent>
        <TabsContent value="donations">
          <Card>
            <CardHeader>
              <CardTitle>Recent Donations</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="p-2 bg-gray-100 rounded">
                  <p className="font-semibold">Book Bundle</p>
                  <p className="text-sm text-gray-600">5 books - Fiction collection</p>
                  <p className="text-sm text-gray-600">Delivery method: Collection</p>
                  <Button size="sm" className="mt-2">Contact Donor</Button>
                </li>
                <li className="p-2 bg-gray-100 rounded">
                  <p className="font-semibold">Single Book: "To Kill a Mockingbird"</p>
                  <p className="text-sm text-gray-600">Condition: Very Good</p>
                  <p className="text-sm text-gray-600">Delivery method: Donor will deliver</p>
                  <Button size="sm" className="mt-2">Contact Donor</Button>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

