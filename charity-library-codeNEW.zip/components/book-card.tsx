import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Heart } from 'lucide-react'

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

interface BookCardProps {
  book: Book
  compact?: boolean
}

export function BookCard({ book, compact }: BookCardProps) {
  if (compact) {
    return (
      <div className="rounded-lg border-2 border-gray-200 bg-card text-card-foreground shadow-sm overflow-hidden">
        <div className="relative aspect-[3/4] w-full">
          <Image
            src={book.image}
            alt={book.title}
            fill
            className="object-cover"
          />
        </div>
        <div className="p-2 space-y-1">
          <h3 className="font-semibold text-sm leading-tight truncate">{book.title}</h3>
          <p className="text-xs text-muted-foreground truncate">by {book.author}</p>
          <div className="flex items-center justify-between pt-1">
            <span className="font-semibold text-sm">£{book.price.toFixed(2)}</span>
            <div className="flex space-x-1">
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Heart className="h-4 w-4" />
                <span className="sr-only">Add to Wishlist</span>
              </Button>
              <Button size="sm" className="h-8 w-8 p-0">
                <ShoppingCart className="h-4 w-4" />
                <span className="sr-only">Add to Basket</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }
  return (
    <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
      <div className="relative aspect-[3/4] w-full">
        <Image
          src={book.image}
          alt={book.title}
          fill
          className="object-cover rounded-t-lg"
        />
      </div>
      <div className="p-4 space-y-3">
        <div className="flex gap-2 flex-wrap">
          {book.categories.map((category) => (
            <Badge key={category} variant="secondary">
              {category}
            </Badge>
          ))}
        </div>
        <h3 className="font-semibold text-lg leading-tight">{book.title}</h3>
        <p className="text-sm text-muted-foreground">by {book.author}</p>
        <p className="text-sm text-muted-foreground">from {book.charityShop}</p>
        <div className="flex items-center justify-between pt-2">
          <span className="font-semibold">£{book.price.toFixed(2)}</span>
          <Button size="sm" className="flex gap-2">
            <ShoppingCart className="h-4 w-4" />
            Add to Basket
          </Button>
        </div>
      </div>
    </div>
  )
}

