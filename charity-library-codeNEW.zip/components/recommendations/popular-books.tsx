"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookCard } from "@/components/book-card"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
}

export function PopularBooks() {
  const [popularBooks, setPopularBooks] = useState<Book[]>([])

  useEffect(() => {
    // In a real application, this would be an API call to get popular books
    const fetchPopularBooks = async () => {
      // Simulating an API call with setTimeout
      setTimeout(() => {
        setPopularBooks([
          {
            id: 1,
            title: "The Alchemist",
            author: "Paulo Coelho",
            price: 8.99,
            categories: ["Fiction", "Philosophy"],
            image: "/placeholder.svg",
            charityShop: "BookLove Charity Shop"
          },
          {
            id: 2,
            title: "Harry Potter and the Philosopher's Stone",
            author: "J.K. Rowling",
            price: 9.99,
            categories: ["Fiction", "Fantasy"],
            image: "/placeholder.svg",
            charityShop: "ReadWell Charity"
          },
          {
            id: 3,
            title: "The Da Vinci Code",
            author: "Dan Brown",
            price: 7.99,
            categories: ["Fiction", "Thriller"],
            image: "/placeholder.svg",
            charityShop: "LiteracyFirst Charity"
          }
        ])
      }, 1000)
    }

    fetchPopularBooks()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Popular Books</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {popularBooks.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

