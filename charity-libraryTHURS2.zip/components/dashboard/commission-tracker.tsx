"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CommissionEntry {
  id: string
  date: string
  bookTitle: string
  saleAmount: number
  commissionRate: number
  commissionAmount: number
}

export function CommissionTracker() {
  const [timeFrame, setTimeFrame] = useState("this-month")
  const [commissionEntries, setCommissionEntries] = useState<CommissionEntry[]>([
    {
      id: "COM-001",
      date: "2023-06-15",
      bookTitle: "The Great Gatsby",
      saleAmount: 9.99,
      commissionRate: 0.05,
      commissionAmount: 0.50,
    },
    {
      id: "COM-002",
      date: "2023-06-18",
      bookTitle: "To Kill a Mockingbird",
      saleAmount: 11.49,
      commissionRate: 0.05,
      commissionAmount: 0.57,
    },
  ])

  const totalCommission = commissionEntries.reduce((sum, entry) => sum + entry.commissionAmount, 0)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Commission Tracker</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <Select value={timeFrame} onValueChange={setTimeFrame}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time frame" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this-week">This Week</SelectItem>
              <SelectItem value="this-month">This Month</SelectItem>
              <SelectItem value="last-month">Last Month</SelectItem>
              <SelectItem value="last-3-months">Last 3 Months</SelectItem>
            </SelectContent>
          </Select>
          <div className="text-lg font-semibold">
            Total Commission: £{totalCommission.toFixed(2)}
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Book Title</TableHead>
              <TableHead>Sale Amount</TableHead>
              <TableHead>Commission Rate</TableHead>
              <TableHead>Commission Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {commissionEntries.map((entry) => (
              <TableRow key={entry.id}>
                <TableCell>{entry.date}</TableCell>
                <TableCell>{entry.bookTitle}</TableCell>
                <TableCell>£{entry.saleAmount.toFixed(2)}</TableCell>
                <TableCell>{(entry.commissionRate * 100).toFixed(2)}%</TableCell>
                <TableCell>£{entry.commissionAmount.toFixed(2)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

