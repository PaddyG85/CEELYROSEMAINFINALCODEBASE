"use client"

import { useState } from "react"
import { Search, MapPin, Store, Book } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"

export function SearchBar() {
  const [searchType, setSearchType] = useState("books")
  const [distance, setDistance] = useState([10])
  const [postcode, setPostcode] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [categories, setCategories] = useState<string[]>([])

  const handleCategoryChange = (category: string) => {
    setCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    )
  }

  const handleSearch = () => {
    console.log({
      type: searchType,
      query: searchQuery,
      distance: distance[0],
      postcode,
      categories,
    })
  }

  return (
    <div className="w-full max-w-3xl mx-auto space-y-4">
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline">Filters</Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Search Filters</SheetTitle>
              <SheetDescription>
                Refine your search with additional filters
              </SheetDescription>
            </SheetHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label>Search Type</Label>
                <RadioGroup
                  defaultValue={searchType}
                  onValueChange={(value) => setSearchType(value)}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="books" id="books" />
                    <Label htmlFor="books">Books</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="shops" id="shops" />
                    <Label htmlFor="shops">Charity Shops</Label>
                  </div>
                </RadioGroup>
              </div>
              <div className="space-y-2">
                <Label>Distance (miles)</Label>
                <Slider
                  value={distance}
                  onValueChange={setDistance}
                  max={50}
                  step={1}
                />
                <div className="text-sm text-muted-foreground">
                  Within {distance} miles
                </div>
              </div>
              <div className="space-y-2">
                <Label>Postcode</Label>
                <div className="relative">
                  <Input
                    type="text"
                    value={postcode}
                    onChange={(e) => setPostcode(e.target.value)}
                    placeholder="Enter postcode"
                    className="pl-10"
                  />
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Categories</Label>
                <div className="grid grid-cols-2 gap-2">
                  {["Fiction", "Non-Fiction", "Mystery", "Sci-Fi", "Biography"].map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-${category}`}
                        checked={categories.includes(category)}
                        onCheckedChange={() => handleCategoryChange(category)}
                      />
                      <label
                        htmlFor={`category-${category}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <Button onClick={handleSearch} className="w-full">
              Apply Filters
            </Button>
          </SheetContent>
        </Sheet>
        <Button onClick={handleSearch}>Search</Button>
      </div>
      <div className="flex gap-4 px-2">
        <Button
          variant={searchType === "books" ? "default" : "ghost"}
          size="sm"
          onClick={() => setSearchType("books")}
          className="flex gap-2"
        >
          <Book className="h-4 w-4" />
          Books
        </Button>
        <Button
          variant={searchType === "shops" ? "default" : "ghost"}
          size="sm"
          onClick={() => setSearchType("shops")}
          className="flex gap-2"
        >
          <Store className="h-4 w-4" />
          Charity Shops
        </Button>
      </div>
    </div>
  )
}

