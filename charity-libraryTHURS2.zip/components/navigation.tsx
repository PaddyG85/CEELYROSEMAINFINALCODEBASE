"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart, User, Menu, X } from 'lucide-react'
import { Badge } from "@/components/ui/badge"

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [cartCount, setCartCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const closeMenu = () => setIsMenuOpen(false)

  return (
    <nav className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-semibold text-primary">
              CeelyRose
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/books-just-added" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">
                Books Just Added
              </Link>
              <Link href="/nationwide-library" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">
                Nationwide Library
              </Link>
              <Link href="/charity-shops" className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">
                Charity Shops
              </Link>
              <div className="relative group">
                <button className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">
                  More
                </button>
                <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden group-hover:block">
                  <Link href="/about" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">About Us</Link>
                  <Link href="/contact" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Contact</Link>
                  <Link href="/faq" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">FAQ</Link>
                  <Link href="/donate-books" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Donate Books</Link>
                  <Link href="/terms" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Terms of Service</Link>
                  <Link href="/privacy" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Privacy Policy</Link>
                </div>
              </div>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/cart" className="text-gray-600 hover:text-gray-900 relative">
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <Badge variant="destructive" className="absolute -top-2 -right-2">
                  {cartCount}
                </Badge>
              )}
            </Link>
            <Link href="/wishlist" className="text-gray-600 hover:text-gray-900 relative">
              <Heart className="h-6 w-6" />
              {wishlistCount > 0 && (
                <Badge variant="destructive" className="absolute -top-2 -right-2">
                  {wishlistCount}
                </Badge>
              )}
            </Link>
            <Button variant="ghost" asChild>
              <Link href="/profile">
                <User className="h-6 w-6 mr-2" />
                Profile
              </Link>
            </Button>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground" asChild>
              <Link href="/sign-in">Sign In</Link>
            </Button>
          </div>
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-teal-500"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/books-just-added" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Books Just Added
            </Link>
            <Link href="/nationwide-library" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Nationwide Library
            </Link>
            <Link href="/charity-shops" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Charity Shops
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              About
            </Link>
            <Link href="/contact" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Contact
            </Link>
            <Link href="/faq" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              FAQ
            </Link>
            <Link href="/terms" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Terms of Service
            </Link>
            <Link href="/privacy" className="text-gray-600 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium" onClick={closeMenu}>
              Privacy Policy
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-5">
              <div className="flex-shrink-0">
                <User className="h-10 w-10 rounded-full" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-gray-800">User Name</div>
                <div className="text-sm font-medium text-gray-500">user@example.com</div>
              </div>
            </div>
            <div className="mt-3 px-2 space-y-1">
              <Link href="/profile" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100" onClick={closeMenu}>
                Profile
              </Link>
              <Link href="/cart" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100" onClick={closeMenu}>
                Cart
              </Link>
              <Link href="/wishlist" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100" onClick={closeMenu}>
                Wishlist
              </Link>
              <Link href="/sign-in" className="block px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100" onClick={closeMenu}>
                Sign In
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}

