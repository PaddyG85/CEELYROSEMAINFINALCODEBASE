"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCartIcon, Heart, Trash2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from 'next/link'

interface CartItem {
  id: number
  title: string
  price: number
  quantity: number
}

export function ShoppingCart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    { id: 1, title: "The Great Gatsby", price: 9.99, quantity: 1 },
    { id: 2, title: "To Kill a Mockingbird", price: 12.99, quantity: 2 },
  ])

  const [wishlistItems, setWishlistItems] = useState<CartItem[]>([
    { id: 3, title: "1984", price: 10.99, quantity: 1 },
    { id: 4, title: "Pride and Prejudice", price: 8.99, quantity: 1 },
  ])

  const removeItem = (id: number, isWishlist: boolean) => {
    if (isWishlist) {
      setWishlistItems(wishlistItems.filter(item => item.id !== id))
    } else {
      setCartItems(cartItems.filter(item => item.id !== id))
    }
  }

  const updateQuantity = (id: number, newQuantity: number, isWishlist: boolean) => {
    const updateItems = (items: CartItem[]) =>
      items.map(item => item.id === id ? { ...item, quantity: newQuantity } : item)
    
    if (isWishlist) {
      setWishlistItems(updateItems(wishlistItems))
    } else {
      setCartItems(updateItems(cartItems))
    }
  }

  const moveToCart = (id: number) => {
    const item = wishlistItems.find(item => item.id === id)
    if (item) {
      setCartItems([...cartItems, item])
      setWishlistItems(wishlistItems.filter(item => item.id !== id))
    }
  }

  const calculateTotal = (items: CartItem[]) =>
    items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  const renderItems = (items: CartItem[], isWishlist: boolean) => (
    <>
      {items.map(item => (
        <div key={item.id} className="flex items-center justify-between border-b py-2">
          <div>
            <h3 className="font-semibold">{item.title}</h3>
            <p className="text-sm text-gray-600">£{item.price.toFixed(2)}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1), isWishlist)}
              >
                -
              </Button>
              <span className="mx-2">{item.quantity}</span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => updateQuantity(item.id, item.quantity + 1, isWishlist)}
              >
                +
              </Button>
            </div>
            {isWishlist && (
              <Button variant="outline" size="sm" onClick={() => moveToCart(item.id)}>
                Add to Cart
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => removeItem(item.id, isWishlist)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </>
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Shopping Cart</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="cart">
          <TabsList>
            <TabsTrigger value="cart">Cart</TabsTrigger>
            <TabsTrigger value="wishlist">Wishlist</TabsTrigger>
          </TabsList>
          <TabsContent value="cart">
            {cartItems.length === 0 ? (
              <p>Your cart is empty.</p>
            ) : (
              <>
                {renderItems(cartItems, false)}
                <div className="flex justify-between items-center font-bold text-lg pt-4">
                  <span>Total:</span>
                  <span>£{calculateTotal(cartItems).toFixed(2)}</span>
                </div>
                <Button className="w-full mt-4" asChild>
                  <Link href="/checkout">Proceed to Checkout</Link>
                </Button>
              </>
            )}
          </TabsContent>
          <TabsContent value="wishlist">
            {wishlistItems.length === 0 ? (
              <p>Your wishlist is empty.</p>
            ) : (
              renderItems(wishlistItems, true)
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

