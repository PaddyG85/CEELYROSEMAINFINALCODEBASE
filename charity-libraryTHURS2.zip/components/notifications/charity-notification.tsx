"use client"

import { useState, useEffect } from "react"
import { Bell } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Notification {
  id: number
  message: string
  read: boolean
}

export function CharityNotification() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showNotifications, setShowNotifications] = useState(false)

  // This would typically fetch notifications from an API
  useEffect(() => {
    // Simulating API call
    setTimeout(() => {
      setNotifications([
        { id: 1, message: "New book donation received", read: false },
        { id: 2, message: "Book bundle ready for collection", read: false },
      ])
    }, 1000)
  }, [])

  const unreadCount = notifications.filter(n => !n.read).length

  const handleNotificationClick = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ))
  }

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setShowNotifications(!showNotifications)}
        className="relative"
      >
        <Bell className="h-6 w-6" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
            {unreadCount}
          </span>
        )}
      </Button>
      {showNotifications && (
        <Card className="absolute right-0 mt-2 w-64 z-10">
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
          </CardHeader>
          <CardContent>
            {notifications.length === 0 ? (
              <p>No new notifications</p>
            ) : (
              <ul className="space-y-2">
                {notifications.map(notification => (
                  <li
                    key={notification.id}
                    className={`p-2 rounded cursor-pointer ${
                      notification.read ? 'bg-gray-100' : 'bg-blue-100'
                    }`}
                    onClick={() => handleNotificationClick(notification.id)}
                  >
                    {notification.message}
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

