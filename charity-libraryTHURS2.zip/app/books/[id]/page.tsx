"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { ShoppingCart, Heart } from 'lucide-react'
import Link from "next/link"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

interface Book {
  id: number
  title: string
  author: string
  price: number
  condition: string
  description: string
  images: string[]
  charityShop: string
  charityShopId: number
}

export default function BookDetailsPage({ params }: { params: { id: string } }) {
  const [book, setBook] = useState<Book | null>(null)

  useEffect(() => {
    // Fetch book details
    // This is a mock fetch, replace with actual API call
    setBook({
      id: parseInt(params.id),
      title: "To Kill a Mockingbird",
      author: "Harper Lee",
      price: 5.99,
      condition: "Good",
      description: "To Kill a Mockingbird is a novel by Harper Lee published in 1960. It was immediately successful, winning the Pulitzer Prize and becoming a classic of modern American literature.",
      images: ["/placeholder.svg", "/placeholder.svg", "/placeholder.svg", "/placeholder.svg"],
      charityShop: "BookLove Charity Shop",
      charityShopId: 1,
    })
  }, [params.id])

  if (!book) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid md:grid-cols-2 gap-8">
        <Card className="md:col-span-2 lg:col-span-1">
          <CardContent className="p-4">
            <Carousel>
              <CarouselContent>
                {book.images.map((image, index) => (
                  <CarouselItem key={index}>
                    <div className="aspect-square relative overflow-hidden rounded-lg">
                      <Image
                        src={image}
                        alt={`${book.title} - Image ${index + 1}`}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </CardContent>
        </Card>
        <Card className="md:col-span-2 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl">{book.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg mb-2">by {book.author}</p>
            <p className="text-2xl font-bold mb-4">£{book.price.toFixed(2)}</p>
            <p className="mb-4">Condition: {book.condition}</p>
            <p className="mb-4">{book.description}</p>
            <p className="mb-4">Sold by: {book.charityShop}</p>
            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <Button className="flex-1">
                <ShoppingCart className="mr-2 h-4 w-4" />
                Add to Cart
              </Button>
              <Button variant="outline" className="flex-1">
                <Heart className="mr-2 h-4 w-4" />
                Add to Wishlist
              </Button>
            </div>
            <Link href={`/charity-shops/${book.charityShopId}`} className="text-primary hover:underline block text-center sm:text-left">
              View {book.charityShop} Profile
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

