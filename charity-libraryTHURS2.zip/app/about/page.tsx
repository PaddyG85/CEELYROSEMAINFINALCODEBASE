import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-primary">About CeelyRose</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Our Mission</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              At CeelyRose, our mission goes beyond simply connecting readers with second-hand books. We are driven by a pure intent to create a positive impact on society, literacy, and the environment. Our ethos is rooted in the belief that everyone should have access to affordable books while simultaneously supporting charitable causes.
            </p>
            <p className="mb-4">
              By creating a platform where book lovers can purchase pre-loved books from charity shops across the UK, we're not only making literature more accessible but also contributing to various charitable causes. Every purchase made through CeelyRose directly supports local charities, helping them continue their vital work in communities across the nation.
            </p>
            <p className="mb-4">
              Our commitment to affordability ensures that readers from all walks of life can enjoy quality literature without breaking the bank. By giving books a second life, we're also promoting sustainable reading habits and reducing waste, contributing to a greener future.
            </p>
            <p className="mb-4">
              Through CeelyRose, we aim to:
            </p>
            <ul className="list-disc list-inside mb-4">
              <li>Make books accessible and affordable for all</li>
              <li>Support a wide network of UK charities</li>
              <li>Promote literacy and a love for reading</li>
              <li>Encourage sustainable consumption of books</li>
              <li>Create a community of socially conscious readers</li>
            </ul>
            <p>
              Join us in our mission to transform the way we read, give, and make a difference. Every book you purchase through CeelyRose is a step towards a more literate, charitable, and sustainable world.
            </p>
          </CardContent>
        </Card>
        <div>
          <Image
            src="/placeholder.svg"
            alt="CeelyRose Team"
            width={600}
            height={400}
            className="rounded-lg shadow-md mb-4"
          />
          <Card>
            <CardHeader>
              <CardTitle>Our Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Since our inception, CeelyRose has:
              </p>
              <ul className="list-disc list-inside mb-4">
                <li>Facilitated the sale of over 100,000 second-hand books</li>
                <li>Partnered with 500+ charity shops across the UK</li>
                <li>Raised £1 million for various charitable causes</li>
                <li>Saved an estimated 500 tons of paper through book reuse</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

