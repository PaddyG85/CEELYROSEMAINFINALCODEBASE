import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

const collections = [
  { id: 1, name: "Reader's Choice", description: "Top-rated books across various genres", image: "/placeholder.svg" },
  { id: 2, name: "Classic Literature", description: "Timeless works that have shaped literary history", image: "/placeholder.svg" },
  { id: 3, name: "Contemporary Fiction", description: "Modern storytelling at its finest", image: "/placeholder.svg" },
  { id: 4, name: "Non-Fiction Essentials", description: "Informative reads on diverse subjects", image: "/placeholder.svg" },
  { id: 5, name: "Children's Favorites", description: "Beloved stories for young readers", image: "/placeholder.svg" },
  { id: 6, name: "Academic Excellence", description: "Curated selections for schools and universities", image: "/placeholder.svg" },
]

export default function CollectionsAndBundles() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-primary mb-6">Precision Collections & School Bundles</h1>
      <p className="text-lg mb-8">
        Explore our carefully curated collections and bundles, designed to cater to all types of readers and educational needs. Whether you're an individual looking for your next great read, a book club seeking discussion-worthy titles, or a school in need of academic resources, we have the perfect selection for you.
      </p>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {collections.map((collection) => (
          <Card key={collection.id}>
            <CardHeader>
              <CardTitle>{collection.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <Image src={collection.image} alt={collection.name} width={300} height={200} className="mb-4 rounded-md" />
              <p className="mb-4">{collection.description}</p>
              <Button asChild className="w-full">
                <Link href={`/collections-and-bundles/${collection.id}`}>View Collection</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

