"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { BookCard } from "@/components/book-card"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

const categories = [
  {
    name: "Fiction",
    subcategories: ["Classic", "Contemporary", "Science Fiction", "Fantasy", "Mystery"],
  },
  {
    name: "Non-Fiction",
    subcategories: ["Biography", "History", "Science", "Self-Help", "Travel"],
  },
  {
    name: "Children's",
    subcategories: ["Picture Books", "Chapter Books", "Young Adult"],
  },
]

const books = [
  { id: 1, title: "To Kill a Mockingbird", author: "Harper Lee", price: 7.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop" },
  { id: 2, title: "1984", author: "George Orwell", price: 6.99, categories: ["Fiction", "Science Fiction"], image: "/placeholder.svg", charityShop: "ReadWell Charity" },
  { id: 3, title: "The Diary of a Young Girl", author: "Anne Frank", price: 5.99, categories: ["Non-Fiction", "Biography"], image: "/placeholder.svg", charityShop: "LiteracyFirst Charity" },
  { id: 4, title: "Harry Potter and the Philosopher's Stone", author: "J.K. Rowling", price: 8.99, categories: ["Children's", "Fantasy"], image: "/placeholder.svg", charityShop: "PageTurner Foundation" },
]

export default function LibraryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedSubcategory, setSelectedSubcategory] = useState("")
  const [priceRange, setPriceRange] = useState([0, 50])
  const [location, setLocation] = useState("")

  const filteredBooks = books.filter((book) => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          book.author.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory ? book.categories.includes(selectedCategory) : true
    const matchesSubcategory = selectedSubcategory ? book.categories.includes(selectedSubcategory) : true
    const matchesPrice = book.price >= priceRange[0] && book.price <= priceRange[1]
    return matchesSearch && matchesCategory && matchesSubcategory && matchesPrice
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Nationwide Library</h1>
      <div className="grid gap-6 md:grid-cols-4">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Advanced Search</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="search">Search</Label>
                <Input
                  id="search"
                  placeholder="Search books..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="price-range">Price Range</Label>
                <Slider
                  id="price-range"
                  min={0}
                  max={50}
                  step={1}
                  value={priceRange}
                  onValueChange={setPriceRange}
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>£{priceRange[0]}</span>
                  <span>£{priceRange[1]}</span>
                </div>
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="Enter location..."
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="search-nationally" />
                <Label htmlFor="search-nationally">Search Nationally</Label>
              </div>
              <Accordion type="single" collapsible className="w-full">
                {categories.map((category, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger onClick={() => setSelectedCategory(category.name)}>
                      {category.name}
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="ml-4">
                        {category.subcategories.map((subcategory, subIndex) => (
                          <li key={subIndex} className="my-1">
                            <Button
                              variant="link"
                              onClick={() => setSelectedSubcategory(subcategory)}
                            >
                              {subcategory}
                            </Button>
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </CardContent>
        </Card>
        <div className="md:col-span-3">
          <div className="grid gap-6 grid-cols-2 md:grid-cols-3 lg:grid-cols-3">
            {filteredBooks.slice(0, 6).map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

