import Link from 'next/link'
import { Card, CardContent } from "@/components/ui/card"

const categories = [
  { name: "Fiction", subcategories: ["Classic", "Contemporary", "Mystery", "Science Fiction", "Fantasy"] },
  { name: "Non-Fiction", subcategories: ["Biography", "History", "Science", "Self-Help", "Travel"] },
  { name: "Children's", subcategories: ["Picture Books", "Chapter Books", "Young Adult"] },
  { name: "Poetry", subcategories: [] },
  { name: "Drama", subcategories: [] },
  { name: "Reference", subcategories: ["Dictionaries", "Encyclopedias", "Academic"] },
  { name: "Religion & Spirituality", subcategories: [] },
  { name: "Art & Photography", subcategories: [] },
  { name: "Cookbooks", subcategories: [] },
]

export default function NationwideLibraryPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">Nationwide Library</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category) => (
          <Link href={`/nationwide-library/${category.name.toLowerCase().replace(' ', '-')}`} key={category.name}>
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <h2 className="text-2xl font-semibold mb-2">{category.name}</h2>
                {category.subcategories.length > 0 && (
                  <p className="text-sm text-gray-600">
                    Including: {category.subcategories.slice(0, 3).join(', ')}
                    {category.subcategories.length > 3 && '...'}
                  </p>
                )}
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

