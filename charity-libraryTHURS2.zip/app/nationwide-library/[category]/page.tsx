"use client"

import { useState } from 'react'
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { BookCard } from "@/components/book-card"

// This is a mock function to get books. Replace with actual API call in production.
const getBooks = (category: string) => {
  // Mock data
  return [
    { id: 1, title: "To Kill a Mockingbird", author: "Harper Lee", price: 7.99, categories: ["Fiction", "Classic"], image: "/placeholder.svg", charityShop: "BookLove Charity Shop" },
    { id: 2, title: "1984", author: "George Orwell", price: 6.99, categories: ["Fiction", "Science Fiction"], image: "/placeholder.svg", charityShop: "ReadWell Charity" },
    // Add more books as needed
  ]
}

export default function CategoryPage({ params }: { params: { category: string } }) {
  const [searchTerm, setSearchTerm] = useState("")
  const [subcategory, setSubcategory] = useState("All")
  const [priceRange, setPriceRange] = useState([0, 100])
  const [sortBy, setSortBy] = useState("relevance")

  const category = params.category.replace('-', ' ')
  const books = getBooks(category)

  const filteredBooks = books.filter(book => 
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (subcategory === "All" || book.categories.includes(subcategory)) &&
    book.price >= priceRange[0] && book.price <= priceRange[1]
  )

  // Sort books based on sortBy value
  const sortedBooks = [...filteredBooks].sort((a, b) => {
    if (sortBy === "price-low-high") return a.price - b.price
    if (sortBy === "price-high-low") return b.price - a.price
    // Add more sorting options as needed
    return 0
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">{category}</h1>
      
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Advanced Search</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            placeholder="Search books..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="flex space-x-4">
            <Select onValueChange={setSubcategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select subcategory" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Subcategories</SelectItem>
                {/* Add subcategories dynamically based on the main category */}
              </SelectContent>
            </Select>
            <Select onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="price-low-high">Price: Low to High</SelectItem>
                <SelectItem value="price-high-low">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <p className="mb-2">Price Range: £{priceRange[0]} - £{priceRange[1]}</p>
            <Slider
              min={0}
              max={100}
              step={1}
              value={priceRange}
              onValueChange={setPriceRange}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedBooks.map(book => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  )
}

