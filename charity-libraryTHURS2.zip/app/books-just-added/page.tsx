"use client"

import { useState, useEffect } from "react"
import { BookCard } from "@/components/book-card"
import { useInView } from "react-intersection-observer"

interface Book {
  id: number
  title: string
  author: string
  price: number
  categories: string[]
  image: string
  charityShop: string
  addedAt: string
}

function getRelativeTimeString(date: Date): string {
  const now = new Date()
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diffInSeconds < 60) {
    return `${diffInSeconds} seconds ago`
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60)
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600)
    return `${hours} hour${hours > 1 ? 's' : ''} ago`
  } else {
    const days = Math.floor(diffInSeconds / 86400)
    return `${days} day${days > 1 ? 's' : ''} ago`
  }
}

export default function BooksJustAddedPage() {
  const [books, setBooks] = useState<Book[]>([])
  const [loading, setLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const { ref, inView } = useInView()

  const loadMoreBooks = async () => {
    if (loading || !hasMore) return
    setLoading(true)
    // In a real application, you would fetch books from an API
    // This is a mock implementation
    const newBooks = Array.from({ length: 12 }, (_, i) => ({
      id: books.length + i + 1,
      title: `Book ${books.length + i + 1}`,
      author: `Author ${books.length + i + 1}`,
      price: Math.floor(Math.random() * 20) + 5,
      categories: ["Fiction", "Non-Fiction"],
      image: "/placeholder.svg",
      charityShop: `Charity Shop ${Math.floor(Math.random() * 5) + 1}`,
      addedAt: new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toISOString()
    }))
    const sortedBooks = [...books, ...newBooks].sort((a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime())
    setBooks(sortedBooks)
    setLoading(false)
    if (sortedBooks.length >= 100) {
      setHasMore(false)
    }
  }

  useEffect(() => {
    loadMoreBooks()
  }, [])

  useEffect(() => {
    if (inView) {
      loadMoreBooks()
    }
  }, [inView])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Books Just Added</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {books.map((book) => (
          <div key={book.id} className="flex flex-col">
            <BookCard book={book} />
            <p className="text-sm text-gray-600 mt-2">
              Added {getRelativeTimeString(new Date(book.addedAt))}
            </p>
          </div>
        ))}
      </div>
      {hasMore && (
        <div ref={ref} className="h-20 flex items-center justify-center">
          <p>Loading more books...</p>
        </div>
      )}
    </div>
  )
}

